import numpy as np 
import matplotlib.pyplot as plt
import glob
import cv2
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from skimage.morphology import disk, binary_dilation
from skimage.restoration import inpaint
from PIL import Image
from tensorflow.keras.utils import load_img
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, MaxPool2D
from keras.layers import Flatten, Dense
from tkinter import filedialog
import warnings
from sklearn.exceptions import ConvergenceWarning
with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=ConvergenceWarning)

print()

print("<------------ INPUT ------------>")

print()

train_dir = 'data/'
categories = [ 'angry', 'disgusted', 'fearful', 'happy', 'neutral', 'sad', 'surprised']

def count_exp(path, set_):
    dict_ = {}
    for expression in os.listdir(path):
        dir_ = path + expression
        dict_[expression] = len(os.listdir(dir_))
    df = pd.DataFrame(dict_, index=[set_])
    return df
train_count = count_exp(train_dir, 'data')

print(train_count)

#train directory
train_count.transpose().plot(kind='bar')
plt.figure(figsize=(14,22))
i = 1
for expression in os.listdir(train_dir):
    img = load_img((train_dir + expression +'/'+ os.listdir(train_dir + expression)[5]))
    plt.subplot(1,7,i)
    plt.imshow(img)
    plt.title(expression)
    plt.axis('off')
    i += 1
plt.show()

plt.figure(figsize=(14,20))
i = 1


print()

print("<----------- DATA PREPROCESSING ------------>")

print()

SIZE = 48  #Resize images

#Capture training data and labels into respective lists
train_images = []
train_labels = [] 

for directory_path in glob.glob("data/*"):
    label = directory_path.split("/")[-1]
    print(label)
    for img_path in glob.glob(os.path.join(directory_path, "*.png")):
        img = cv2.imread(img_path, cv2.IMREAD_COLOR)       
        img = cv2.resize(img, (SIZE, SIZE))
        img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        train_images.append(img)
        train_labels.append(label)

#Convert lists to arrays        
train_images = np.array(train_images)
train_labels = np.array(train_labels)


print()

print("<----------- DATA SPLITTING ------------->")

print()


#Encode labels from text to integers.
from sklearn import preprocessing
le = preprocessing.LabelEncoder()
le.fit(train_labels)
train_labels_encoded = le.transform(train_labels)


from sklearn.model_selection import train_test_split

(trainX, testX, trainY, testY) = train_test_split(train_images, train_labels_encoded, test_size=0.4, random_state=48)

print(trainX.shape)
print(testX.shape)
print(trainY.shape)
print(testY.shape)


#One hot encode y values for neural network. 
from keras.utils import to_categorical
y_train_one_hot = to_categorical(trainY)
y_test_one_hot = to_categorical(testY)

print()
Image_ = filedialog.askopenfilename()
head_tail = os.path.split(Image_)
fileNo=head_tail[1].split('.')
test_image_o = cv2.imread(head_tail[0]+'/'+fileNo[0]+'.png')

#=====================Image Occlution======================================

image_orig = cv2.resize(test_image_o, (65, 65))

# Create mask with six block defect regions
mask = np.zeros(image_orig.shape[:-1], dtype=bool)
mask[20:60, 0:20] = 1
mask[160:180, 70:155] = 1
mask[30:60, 170:195] = 1
mask[-60:-30, 170:195] = 1
mask[-180:-160, 70:155] = 1
mask[-60:-20, 0:20] = 1

# add a few long, narrow defects
mask[200:205, -200:] = 1
mask[150:255, 20:23] = 1
mask[365:368, 60:130] = 1

# add randomly positioned small point-like defects
rstate = np.random.default_rng(0)
for radius in [0, 2, 4]:
    # larger defects are less common
    thresh = 3 + 0.25 * radius  # make larger defects less common
    tmp_mask = rstate.standard_normal(image_orig.shape[:-1]) > thresh
    if radius > 0:
        tmp_mask = binary_dilation(tmp_mask, disk(radius, dtype=bool))
    mask[tmp_mask] = 1

# Apply defect mask to the image over the same region in each color channel
image_defect = image_orig * ~mask[..., np.newaxis]

image_result = inpaint.inpaint_biharmonic(image_defect, mask, channel_axis=-1)

fig, axes = plt.subplots(ncols=2, nrows=2)
ax = axes.ravel()

plt.set_title('Original image')
plt.imshow(image_orig)

plt.set_title('Mask')
plt.imshow(mask, cmap=plt.cm.gray)

plt.set_title('Defected image')
plt.imshow(image_defect)

plt.set_title('Inpainted image')
plt.imshow(image_result)

fig.tight_layout()
plt.show()


print("<---------------------- IMAGE OCCLUSION ----------------------->")
print("<-------------- SPARSE AUTO ENCODER AND DECODER --------------->")

print()

from numpy import argmax
from sklearn.metrics import confusion_matrix, classification_report
from mlxtend.plotting import plot_confusion_matrix
from time import time
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.layers import Conv2DTranspose

def sparse_autoencoder_train(encoder, decoder, data, epochs, batch, learning_rate=0.0001):
    autoencoder = Sequential([encoder, decoder])
    adam = Adam(lr=learning_rate)
    autoencoder.compile(optimizer=adam, loss='mse')
    start = time()
    autoencoder.fit(data, data, epochs=epochs, batch_size=batch)
    train_time = time() - start
    return encoder, data, train_time

learning_rate=0.001
batch=30
epochs=5
neurons=1024
cur_data = trainX.copy() 
encoder_1 = Sequential()
encoder_1.add(Conv2D(32, (3, 3), activation='relu', padding='same', input_shape=(48,48,3)))
encoder_1.add(MaxPooling2D(pool_size=(2, 2)))
decoder_1 = Sequential([Conv2DTranspose(3, (3, 3), strides=(2, 2), padding='same', input_shape=(24, 24, 32))])
encoder_1, cur_data, cnn_ae_train_time = sparse_autoencoder_train(encoder_1, decoder_1, cur_data, epochs, batch)
cur_data = encoder_1.predict(cur_data) 

cur_data = cur_data.reshape(cur_data.shape[0], 18432)  
encoder_2 = Sequential([Dense(1024, activation='softmax')])
decoder_2 = Sequential([Dense(18432, activation='softmax')])
encoder_2, cur_data, fcnn_ae_train_time = sparse_autoencoder_train(encoder_2, decoder_2, cur_data, epochs, batch)

#defining model
model=Sequential()
#adding convolution layer
model.add(Conv2D(32,(3,3),activation='relu',input_shape=(48,48,3)))
#adding pooling layer
model.add(MaxPool2D(2,2))
#adding fully connected layer=
model.add(Flatten())
model.add(Dense(100,activation='relu'))
#adding output layer
model.add(Dense(7,activation='softmax'))
model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])
model.summary()

history=model.fit(trainX,y_train_one_hot,epochs=10)

print()

print('\nSparse Stack Autoencoder and Decoder train_time: ', cnn_ae_train_time + fcnn_ae_train_time)

print()

print("Accuracy of the CNN is:",model.evaluate(trainX,y_train_one_hot)[1]*100, "%")

print()

print("<--------- PLOTTING THE ACCURACY ---------->")

print()

train_loss = history.history['loss']
train_acc = history.history['accuracy']
plt.figure()
plt.plot(train_loss, label='Loss')
plt.plot(train_acc, label='Accuracy')
plt.title('Performance Plot')
plt.legend()
plt.show()
    
pred = model.predict(testX)
predictions = argmax(pred, axis=1) 
print('Classification Report')
cr=classification_report(testY, predictions,target_names=categories)
print(cr)
print('Confusion Matrix')
cm = confusion_matrix(testY, predictions)
print(cm)

#Confusion Matrix Plot
plt.figure()
plot_confusion_matrix(cm,figsize=(7,7), class_names = categories, show_normed = True);
plt.title( "Model confusion matrix")
plt.style.use("ggplot")
plt.show()

print()

print("<------------------- PREDICTION -------------------->")

print()


test_data=[]
# head_tail = os.path.split(Image_)
# fileNo=head_tail[1].split('.')
# test_image_o = cv2.imread(head_tail[0]+'/'+fileNo[0]+'.png')
test_image = cv2.resize(test_image_o, (SIZE, SIZE))
test_data.append(test_image)

test_data = np.array(test_image, dtype="float") / 255.0
test_data=test_data.reshape([-1,48, 48, 3])
pred = model.predict(test_data)
predictions = argmax(pred, axis=1) 
print ('Prediction : '+categories[predictions[0]])

fig = plt.figure()
fig.patch.set_facecolor('xkcd:white')
plt.title(categories[predictions[0]])
plt.imshow(test_image_o)

 
